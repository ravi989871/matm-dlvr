<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


$servername = "database-1.ckv23lvefwmm.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname = "list_contacts";

$conn_of_lst = mysqli_connect($servername, $username, $password,$dbname);


function cors() {
    
    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }
    
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
        
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    
        exit(0);
    }

}

cors();








function httpGet($url)
{

    $ch = curl_init();

    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false);

    $output=curl_exec($ch);
    curl_close($ch);
    return $output;
}



function update_flg_of_camp_act($conn,$flg,$lst_name,$camp_name,$email){


$update_query_name="update `$lst_name` set `$camp_name`='$flg' where email='$email'";

$conn->query($update_query_name);





}










function send_mail_final($row_data,$data_arr,$camp_name,$conn,$lst_name){

print_r($data_arr);

  $frm_mail=$data_arr['to']['frm_email'];
  $frm_name=$data_arr['to']['frm_name'];

  $prev_fld=$data_arr['tp']['prev_fld'];


  $reply_email=$data_arr['to']['reply_email'];
  $reply_name=$data_arr['to']['reply_name'];
  $email=$row_data['email'];
$temp_url=$data_arr['to']['template_url'];

$html_con=(httpGet(urldecode($temp_url)));

$html_con_of_get=json_decode(rtrim($html_con, "\0"),true);

$sub_fld=$html_con_of_get['subject_line'];



$template=$html_con_of_get['content_for_send'];

if(isset($data_arr['to']['mrg_fld'])){

$merg_data=$row_data[$data_arr['mrg_fld']];

}else{

$merg_data=$row_data['email'];

}





$smtp_host_loc=$data_arr['to']["smtp_host"];
$smtp_usr_loc=$data_arr['to']["smtp_usr"];
$smtp_pass_loc=urldecode($data_arr['to']["smtp_pass"]);
$smtp_port_loc=$data_arr['to']["smtp_port"];


echo $smtp_pass_loc;

require_once "vendor/autoload.php";

$mail = new PHPMailer(true);

//Enable SMTP debugging.
$mail->SMTPDebug = 3;
//Set PHPMailer to use SMTP.
$mail->isSMTP();
//Set SMTP host name
$mail->Host = $smtp_host_loc;
//Set this to true if SMTP host requires authentication to send email

$mail->CharSet = 'UTF-8';

$mail->SMTPAuth = true;
//Provide username and password
$mail->Username = $smtp_usr_loc;
$mail->Password=$smtp_pass_loc;
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";
//Set TCP port to connect to
$mail->Port = $smtp_port_loc;
$mail->From =$frm_mail;
$mail->FromName = $frm_name;
$mail->addReplyTo($reply_email, $reply_name);
$mail->addAddress($email,$merg_data);
$mail->addCustomHeader("List-Unsubscribe-Post","List-Unsubscribe=One-Click");
$mail->addCustomHeader("List-Unsubscribe","<https://api.auftera.com/contact/unsubscribe/mail/".$lst_name."/".$email.">");
$mail->isHTML(true);




$html_con = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />'.$template;



$mail->Subject = $sub_fld;
$mail->Body = $html_con;
$mail->AltBody = $prev_fld;

try {
    $mail->send();


update_flg_of_camp_act($conn,1,$lst_name,$camp_name,$email);
 
} catch (Exception $e) {



update_flg_of_camp_act($conn,-1,$lst_name,$camp_name,$email);
 
}

 
}



$postBody = $_GET['data'];
$data_of_req=json_decode($postBody);

$data_of_req = json_decode(json_encode($data_of_req), true);

$lst_name=$data_of_req['list_name'];
$camp_name=$data_of_req['camp_id'];
$row_data=$data_of_req['contact_data'];
$content_data=$data_of_req['content'];


send_mail_final($row_data,$content_data,$camp_name,$conn_of_lst,$lst_name);
 


















?>

