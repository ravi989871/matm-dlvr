#chmod 777 ./dkim/$i
opendkim-genkey -b 2048 -d $1  -D ./dkim/$1 -s mailatmars -v
