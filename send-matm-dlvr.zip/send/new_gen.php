<?php



$privatekeyfile = 'private.pem';
$publickeyfile  = 'new.pem';
$passphrase     = 'YOUR KEY PASSPHRASE';

// Prepare files
if (file_exists($privatekeyfile)) { unlink($privatekeyfile); }
if (file_exists($publickeyfile))  { unlink($publickeyfile); }
// Generate 2048-bit RSA key with an SHA256 digest
$pk = openssl_pkey_new(
    [
        'digest_alg' => 'sha256',
        'private_key_bits' => 2048,
        'private_key_type' => OPENSSL_KEYTYPE_RSA,
    ]
);
// Export and Save private key
openssl_pkey_export_to_file($pk, $privatekeyfile, $passphrase);
// Save public key
$publickey = openssl_pkey_get_details($pk);
$publickey = $publickey['key'];
file_put_contents($publickeyfile, $publickey);




?>
