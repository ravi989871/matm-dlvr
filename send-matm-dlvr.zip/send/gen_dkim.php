<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}



$domain = $_GET['domain'];
$selector = "mailatmars";

//Private key filename for this selector
$privatekeyfile = "./dkim/".$domain."/".$selector.".private";
//Public key filename for this selector
$publickeyfile = "./dkim/".$domain."/".$selector.".txt";

if (file_exists($privatekeyfile)) {
#    echo "Using existing keys - if you want to generate new keys, delete old key files first.\n\n";
    $privatekey = file_get_contents($privatekeyfile);
    $publickey = file_get_contents($publickeyfile);
} else {

mkdir("./dkim/".$domain,0777); 
	exec("sudo opendkim-genkey -b 2048 -d ".$domain." -D ./dkim/".$domain." -s ".$selector." -v");


$privatekey = file_get_contents($privatekeyfile);
    $publickey = file_get_contents($publickeyfile);

}



$dkim_val=str_replace(["\""," ","\t","\n"],"",get_string_between($publickey, "(", ")"));

echo json_encode(array("key"=>$selector."._domainkey","value"=>$dkim_val));









phpinfo();

?>
