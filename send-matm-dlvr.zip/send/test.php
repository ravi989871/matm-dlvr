<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

function dkim_is_aval($domain){



if(!file_exists("./dkim/".$domain."/mailatmars.private")){






$get_dkim_privat_file= file_get_contents("https://dkim.matmdlvr.com/send/gen_dkim_pri.php?domain=".$domain);

mkdir("./dkim/".$domain,777);

chmod("./dkim/".$domain, 0777);

$myfile = fopen("./dkim/".$domain."/mailatmars.private", "w");
fwrite($myfile,$get_dkim_privat_file);
fclose($myfile);

}
return true;
}

try {
    //Server settings
    $mail->SMTPDebug = 4 ;               //Enable verbose debug output
  $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'localhost';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = false;                                   //Enable SMTP authentication
  $mail->Port       = 2525;       
//$mail->addCustomHeader('x-virtual-mta', 'pmta-vmta1');
    $domain_name=$_GET['domain'];

if(dkim_is_aval($domain_name)){
$mail->Sender='admin@matmdlvr.com';
    $mail->DKIM_domain = $domain_name;
//See the DKIM_gen_keys.phps script for making a key pair -
//here we assume you've already done that.
//Path to your private key:
$mail->DKIM_private = './dkim/'.$domain_name."/mailatmars.private";
//Set this to your own selector
$mail->DKIM_selector = 'mailatmars';
//Put your private key's passphrase in here if it has one
$mail->DKIM_passphrase = '';
//The identity you're signing as - usually your From address
$mail->DKIM_identity = "admin@".$domain_name;
//Suppress listing signed header fields in signature, defaults to true for debugging purpose
$mail->DKIM_copyHeaderFields = false;
//Optionally you can add extra headers for signing to meet special requirements
$mail->DKIM_extraHeaders = ['List-Unsubscribe', 'List-Help'];


}
    //$mail->isSendmail();
    //Recipients
    $mail->setFrom('admin@'.$domain_name, '500apps');
    $mail->addAddress($_GET['email'], 'Joe User');     //Add a recipient
    $mail->addReplyTo('info@example.com', 'Information');

    //Content
    //$mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Why AI is not good';
    $mail->Body    = 'sen test emailfrom php';
   // $mail->AltBody = 'Why AI is not good';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

