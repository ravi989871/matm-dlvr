<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL); 
 */
require("./confige/user_database.php");

$servername = "automation.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname45 = "heptera-api-send-table";
$send_api_table_conn = mysqli_connect($servername, $username, $password,$dbname45);

ini_set('max_execution_time',60);
$url_main="mailatmars.com";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$smtp_id=10;

$smtp_host="email-smtp.us-east-2.amazonaws.com";
$smtp_usr="AKIARBNDRV2BW5RQH2UA";
$smtp_pass="BKLJFMg3y+aI9sOPe6+hsDnZ9rJK61fSCeaue6UAkSQw";
$smtp_port=587;
$pro_validation="";




$res_data=array();





function print_error_code($error_arr){


	echo json_encode($error_arr);

	exit(0);

}



function get_get_query_of_con_data($old_query,$con_data){



$get_query=$old_query;

foreach ($con_data as $key => $value){



$get_query.=$key."=".urlencode($value)."&";


}



return $get_query;

}







function init_smtp_server_data($smtp_id){



$servername ="database-2.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="smtp_data";
$conn_smtp = mysqli_connect($servername, $username, $password,$db);

$GLOBALS['smtp_id']=$smtp_id;




$sel_data_of_smtp="select * from smtp_server_data where smtp_id='$smtp_id'";


$sel_smtp_frm_db=$conn_smtp->query($sel_data_of_smtp);



if ($sel_smtp_frm_db->num_rows > 0) {

$row = $sel_smtp_frm_db->fetch_assoc();


$GLOBALS["smtp_host"]=$row["host"];
$GLOBALS["smtp_usr"]=$row["user_name"];
$GLOBALS["smtp_pass"]=$row["password"];

}else{

$res_data=array("status"=>0,"error_code"=>101,"message"=>"SMTP Server Not Define Fixed manually OR Contact admin","help_link"=>"");

print_error_code($res_data);


}
}




function  init_sender_id_email($coll_id,$id){

$servername ="automation.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="automation";
$auta_conn = mysqli_connect($servername, $username, $password,$db);



$sel_data_of_smtp="select * from `sender_collection` where id='$id' and coll_id='$coll_id'";


$sel_smtp_frm_db=$auta_conn->query($sel_data_of_smtp);




$row = $sel_smtp_frm_db->fetch_assoc();




if ($sel_smtp_frm_db->num_rows > 0) {


$GLOBALS["profile"]=$row;
}else{




	$res_data=array("status"=>0,"error_code"=>201,"message"=>"Set Verify Email In From Field","help_link"=>"");

print_error_code($res_data);

}



}

function get_def_smtp_id($conn,$usr_id){



$sel_smtp_id="select smtp_def from userinfo where id='".$usr_id."'";


$result = $conn->query($sel_smtp_id);



$row = $result->fetch_assoc();


return $row['smtp_def'];


}








if($_SERVER['REQUEST_METHOD']==='POST' && empty($_POST)) {
   $_POST = json_decode(file_get_contents('php://input'),true);
}


//print_r($_POST);
$tag_data=$_POST['tag_data'];
$oauth_token=$_POST['oauth_tokn'];
$email=$_POST['data']['email'];
$merg_data=$_POST['data']['to-name'];
$sub_fld=$_POST['data']['subject'];

$lst_id=$_POST['data']['lst_id'];
$send_tp="normal";
if(isset($_POST['data']['tp_dir'])){
$send_tp=$_POST['data']['tp_dir'];
}



if(!isset($_POST['data']['subject'])){

	$res_data=array("status"=>0,"error_code"=>202,"message"=>"Please Set Subject Line In Request","help_link"=>"");
print_error_code($res_data);

}





if(isset($_POST['data']['collection_id'])){

init_sender_id_email($_POST['data']['collection_id'],$_POST['req_usr_id']);

}else{

	$res_data=array("status"=>0,"error_code"=>702,"message"=>"Select Collection Id ","help_link"=>"");
print_error_code($res_data);
}

if(isset($_POST['data']['smtp_id'])){




init_smtp_server_data($_POST['data']['smtp_id']);


}else{

	init_smtp_server_data(get_def_smtp_id($conn_usr,$_POST['req_usr_id']));
}





$camp_name=strtotime(gmdate("Y-m-d H:i:s"));


if($_POST['data']['type_send']=="txt"){



	$cnt_data="text";

$template=$_POST['data']['content'];

}else if($_POST['data']['type_send']=="template"){
$cnt_data=$_POST['data']['content'];
if($send_tp=='direct'){

$temp_id=rawurlencode($cnt_data).".html";
$html_temp_data="https://template.mailatmars.com/template/crt-template/crtedtemp/".$temp_id;
$template=file_get_contents($html_temp_data);


	}else if($send_tp=="automation"){



$email=$_POST['usr_data']['email'];
		$merg_data=$_POST['usr_data']['email'];
$get_query=get_get_query_of_con_data("",$_POST['usr_data']);

$camp_name=urldecode($_POST['data']['dynamic_content']['auta_name']."|".$_POST['data']['dynamic_content']['act_id']);

$get_query=get_get_query_of_con_data($get_query,$_POST['data']['dynamic_content']);
	$temp_id=rawurlencode($_POST['data']['content']).".php";
$usr_id=explode('^',$lst_id)[0];


$html_temp_data="https://automation.mailatmars.com/automation/template/".$temp_id."?".$get_query."lst_name=".$lst_id;


$template=file_get_contents($html_temp_data);

	}else{




$get_query=get_get_query_of_con_data("",$_POST['usr_data']);



$get_query=get_get_query_of_con_data($get_query,$_POST['data']['dynamic_content']);


$temp_id=rawurlencode($_POST['data']['content']).".php";

$usr_id=explode('^',$lst_id)[0];

$html_temp_data="https://dev.mailatmars.com/dev/api_temp/".$temp_id."?".$get_query."lst_name=".$lst_id."&camp_name=".$camp_name."&usr_id=".$usr_id;


$template=file_get_contents($html_temp_data);
}

}

if(empty($template)){

$res_data=array("status"=>0,"error_code"=>301,"message"=>"Send Valid Content Data","help_link"=>"");

print_error_code($res_data);


}




require_once "vendor/autoload.php";




$mail = new PHPMailer(true);

//$mail->SMTPDebug  = SMTP::DEBUG_SERVER;

if(explode(".",$smtp_host)[1]=="matmdlvr"){

$frm_mail=$GLOBALS["profile"]['from_email'];

//$mail->isSendmail();

$mail->isSMTP();
$mail->Host       = 'localhost';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = false;                                   //Enable SMTP authentication
  $mail->Port       = 2525;


$domain_name=explode("@",$frm_mail)[1];

$mail->DKIM_domain = $domain_name;
//See the DKIM_gen_keys.phps script for making a key pair -
//here we assume you've already done that.
//Path to your private key:
$mail->DKIM_private = "./dkim/".$domain_name."/mailatmars.private";
//Set this to your own selector
$mail->DKIM_selector = 'mailatmars';
//Put your private key's passphrase in here if it has one
$mail->DKIM_passphrase = '';
//The identity you're signing as - usually your From address
$mail->DKIM_identity = "mail@".$domain_name;
//Suppress listing signed header fields in signature, defaults to true for debugging purpose
$mail->DKIM_copyHeaderFields = false;
//Optionally you can add extra headers for signing to meet special requirements
$mail->DKIM_extraHeaders = ['List-Unsubscribe', 'List-Help'];


}else{
$mail->isSMTP();
$mail->CharSet = 'UTF-8';



$mail->Host = $smtp_host;//Set this to true if SMTP host requires authentication to send email
$mail->SMTPAuth = true;
//Provide username and password
//$mail->SMTPSecure = "tls";
$mail->Username=$smtp_usr;
$mail->Password = $smtp_pass;
//If SMTP requires TLS encryption then set it
//Set TCP port to connect to
$mail->Port = $smtp_port;


//echo strpos($smtp_host,".amazonaws.com");

if(strpos($smtp_host, '.amazonaws.com') !== false){

	$mail->SMTPSecure = "tls";
}else{
//$mail->SMTPAuth = false;
$mail->SMTPAutoTLS = false;


}

}

$mail->Sender=$GLOBALS["profile"]['from_email'];



//$mail->SMTPAuth = false;
//$mail->SMTPAutoTLS = false;
$mail->From = $GLOBALS["profile"]['from_email'];
$mail->FromName = $GLOBALS["profile"]['from_name'];
$mail->addReplyTo($GLOBALS["profile"]['reply_email'],  $GLOBALS["profile"]['reply_name']);
$mail->addAddress($email,$merg_data);
//echo $email;
$mail->isHTML(true);
//$mail->addReplyTo('ravigorasiya65@gmail.com', 'Rav');



$con_id=$_POST['usr_data']['con_id'];
$email_cc=$usr_id."+".$camp_name."+".$con_id."+auta@builtup.tech";


$mail->addReplyTo($email_cc, $reply_name);


$html_con = '<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><meta  content="width=device-width, initial-scale=1.0" name="viewport">'.$template;


$mail->Subject = $sub_fld;
$mail->Body = $html_con;
$mail->AltBody = $sub_fld;

try {

    $mail->send();



$isrt_od_send_stat_dt="insert into `$oauth_token` (lst_id,con_id,content_dt,camp_name,tag,smtp_id,sender_id,status) value('$lst_id','$con_id','$cnt_data','$camp_name','$tag_data','$smtp_id','$pro_validation','1')";



$send_api_table_conn->query($isrt_od_send_stat_dt);

$res_data=array("status"=>1,"suc_code"=>501,"message"=>array("con_id"=>$con_id,"list_id"=>$lst_id,"content_data"=>$cnt_data),"help_link"=>"");

print_error_code($res_data);

} catch (Exception $e) {



	$res_data=array("status"=>0,"error_code"=>102,"message"=>"Check Valid SMTP Credential OR Contact ADMIN","help_link"=>"");

print_error_code($res_data);
}


?>

