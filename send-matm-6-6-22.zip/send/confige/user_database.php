<?php
$servername = "database-2.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$db="signup";

$conn_usr = mysqli_connect($servername, $username, $password,$db);

?>
